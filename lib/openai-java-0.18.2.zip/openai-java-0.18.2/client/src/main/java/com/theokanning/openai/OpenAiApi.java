package com.theokanning.openai;

/**
 * @deprecated Use {@link com.theokanning.openai.client.OpenAiApi}
 */
@Deprecated
public interface OpenAiApi extends com.theokanning.openai.client.OpenAiApi {
	// For legacy compatibility only.
}
