package com.theokanning.openai.billing;

import lombok.Data;

/**
 *
 *
 */
@Data
public class Plan {
    private String title;
    private String id;
}
